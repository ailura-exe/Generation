package com.example.prueba3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prueba3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
